import React from 'react';
import { inputFeatures } from '../data/mock';
import '../styles/InputFeatures.css';

const InputFeatures = () => {
  return (
    <section className="input-features-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Input Features</h2>
          <p className="section-description">
            Seven critical parameters that drive accurate crop recommendations
          </p>
        </div>
        
        <div className="features-grid">
          {inputFeatures.map((feature, index) => (
            <div key={index} className="feature-card">
              <div className="feature-card-header">
                <span className="feature-icon-large">{feature.icon}</span>
                <div>
                  <h3 className="feature-name">{feature.name}</h3>
                  <span className="feature-unit">{feature.unit}</span>
                </div>
              </div>
              <p className="feature-description">{feature.description}</p>
              <div className="feature-range">
                <span className="range-label">Range:</span>
                <span className="range-value">{feature.range}</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="features-note">
          <p className="note-text">
            <strong>Note:</strong> All seven features are required for accurate prediction. The model uses ensemble learning to identify complex patterns and relationships between these parameters.
          </p>
        </div>
      </div>
    </section>
  );
};

export default InputFeatures;
