import React from 'react';
import { Sprout } from 'lucide-react';
import '../styles/HeroSection.css';

const HeroSection = ({ onTryDemo }) => {
  return (
    <section className="hero-section">
      <div className="hero-overlay"></div>
      <div className="hero-content">
        <div className="hero-icon-wrapper">
          <Sprout className="hero-icon" size={56} />
        </div>
        <h1 className="hero-title">
          AI Crop Recommendation System
        </h1>
        <p className="hero-subtitle">
          Leveraging Machine Learning to optimize agricultural productivity through intelligent crop selection based on soil and environmental parameters
        </p>
        <div className="hero-stats">
          <div className="stat-item">
            <span className="stat-value">96.8%</span>
            <span className="stat-label">Accuracy</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-value">22+</span>
            <span className="stat-label">Crops</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-value">7</span>
            <span className="stat-label">Features</span>
          </div>
        </div>
        <button className="btn-primary hero-cta" onClick={onTryDemo}>
          Try Crop Prediction
        </button>
      </div>
      <div className="hero-image-container">
        <img 
          src="https://images.unsplash.com/photo-1761839257144-297ce252742e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzR8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhZ3JpY3VsdHVyZSUyMHRlY2hub2xvZ3l8ZW58MHx8fHwxNzc1ODAwNDkwfDA&ixlib=rb-4.1.0&q=85"
          alt="Modern Agriculture Technology"
          className="hero-image"
        />
      </div>
    </section>
  );
};

export default HeroSection;
