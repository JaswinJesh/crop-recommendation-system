import React from 'react';
import { GraduationCap, Mail, Github, Linkedin } from 'lucide-react';
import '../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <div className="footer-logo">
              <GraduationCap size={32} />
              <span className="footer-brand">AI Crop Recommendation</span>
            </div>
            <p className="footer-description">
              A Machine Learning project developed as part of academic curriculum to demonstrate practical applications of Random Forest algorithm in agricultural domain.
            </p>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-heading">Project Details</h3>
            <ul className="footer-list">
              <li className="footer-list-item">
                <strong>Institution:</strong> XYZ University
              </li>
              <li className="footer-list-item">
                <strong>Department:</strong> Computer Science & Engineering
              </li>
              <li className="footer-list-item">
                <strong>Course:</strong> Machine Learning (CSE-401)
              </li>
              <li className="footer-list-item">
                <strong>Academic Year:</strong> 2024-2025
              </li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-heading">Team Members</h3>
            <ul className="footer-list">
              <li className="footer-list-item">Student Name 1 - Roll No. 001</li>
              <li className="footer-list-item">Student Name 2 - Roll No. 002</li>
              <li className="footer-list-item">Student Name 3 - Roll No. 003</li>
            </ul>
            <div className="supervisor-info">
              <strong>Project Guide:</strong> Prof. ABC XYZ
            </div>
          </div>
          
          <div className="footer-section">
            <h3 className="footer-heading">Connect</h3>
            <div className="footer-social">
              <a href="mailto:project@university.edu" className="social-link" aria-label="Email">
                <Mail size={20} />
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="social-link" aria-label="GitHub">
                <Github size={20} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="social-link" aria-label="LinkedIn">
                <Linkedin size={20} />
              </a>
            </div>
            <div className="footer-tech">
              <h4 className="tech-heading">Built With</h4>
              <div className="tech-stack">
                <span className="tech-badge">Python</span>
                <span className="tech-badge">Scikit-learn</span>
                <span className="tech-badge">React</span>
                <span className="tech-badge">Random Forest</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p className="footer-copyright">
            © 2024 AI Crop Recommendation System. Developed for academic purposes.
          </p>
          <p className="footer-disclaimer">
            This is a college project for educational purposes. Predictions should be verified with agricultural experts before implementation.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
