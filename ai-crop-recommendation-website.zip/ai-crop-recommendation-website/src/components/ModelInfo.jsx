import React from 'react';
import { GitBranch, Layers, BarChart3, CheckCircle } from 'lucide-react';
import '../styles/ModelInfo.css';

const ModelInfo = () => {
  const modelSpecs = [
    {
      icon: <Layers size={24} />,
      label: 'Algorithm',
      value: 'Random Forest',
      detail: 'Ensemble Learning',
    },
    {
      icon: <GitBranch size={24} />,
      label: 'Estimators',
      value: '100 Trees',
      detail: 'Decision Trees',
    },
    {
      icon: <BarChart3 size={24} />,
      label: 'Training Data',
      value: '2,500+',
      detail: 'Data Samples',
    },
    {
      icon: <CheckCircle size={24} />,
      label: 'Accuracy',
      value: '96.8%',
      detail: 'Test Set',
    },
  ];

  return (
    <section className="model-info-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Model Architecture</h2>
          <p className="section-description">
            Built with Random Forest - a powerful ensemble learning algorithm
          </p>
        </div>
        
        <div className="model-content">
          <div className="model-description">
            <h3 className="model-subtitle">Why Random Forest?</h3>
            <p className="model-text">
              Random Forest is an ensemble learning method that constructs multiple decision trees during training and outputs the mode of classes for classification. It's particularly effective for agricultural data due to its ability to handle non-linear relationships and prevent overfitting.
            </p>
            
            <div className="model-advantages">
              <h4 className="advantages-title">Key Advantages</h4>
              <ul className="advantages-list">
                <li className="advantage-item">
                  <CheckCircle size={18} className="advantage-icon" />
                  <span>High accuracy with minimal hyperparameter tuning</span>
                </li>
                <li className="advantage-item">
                  <CheckCircle size={18} className="advantage-icon" />
                  <span>Robust to outliers and missing values</span>
                </li>
                <li className="advantage-item">
                  <CheckCircle size={18} className="advantage-icon" />
                  <span>Provides feature importance rankings</span>
                </li>
                <li className="advantage-item">
                  <CheckCircle size={18} className="advantage-icon" />
                  <span>Handles both numerical and categorical data</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="model-specs-grid">
            {modelSpecs.map((spec, index) => (
              <div key={index} className="spec-card">
                <div className="spec-icon">{spec.icon}</div>
                <div className="spec-content">
                  <span className="spec-label">{spec.label}</span>
                  <span className="spec-value">{spec.value}</span>
                  <span className="spec-detail">{spec.detail}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="training-info">
          <h3 className="training-title">Training Process</h3>
          <p className="training-text">
            The model was trained using scikit-learn's RandomForestClassifier with optimized hyperparameters. Data preprocessing included feature scaling using StandardScaler and train-test split (80-20 ratio) for validation. Cross-validation was performed to ensure model generalization.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ModelInfo;
