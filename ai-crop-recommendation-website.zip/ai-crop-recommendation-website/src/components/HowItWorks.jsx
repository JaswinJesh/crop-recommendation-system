import React from 'react';
import { howItWorksSteps } from '../data/mock';
import { ArrowRight } from 'lucide-react';
import '../styles/HowItWorks.css';

const HowItWorks = () => {
  return (
    <section className="how-it-works-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">How It Works</h2>
          <p className="section-description">
            A four-step process from data collection to crop recommendation
          </p>
        </div>
        
        <div className="steps-container">
          {howItWorksSteps.map((step, index) => (
            <React.Fragment key={step.step}>
              <div className="step-card">
                <div className="step-number">{step.step}</div>
                <div className="step-icon">{step.icon}</div>
                <h3 className="step-title">{step.title}</h3>
                <p className="step-description">{step.description}</p>
              </div>
              {index < howItWorksSteps.length - 1 && (
                <div className="step-arrow">
                  <ArrowRight size={24} />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
        
        <div className="workflow-info">
          <div className="workflow-card">
            <h4 className="workflow-title">Machine Learning Pipeline</h4>
            <div className="workflow-steps">
              <span className="workflow-step">Input Validation</span>
              <span className="workflow-arrow">→</span>
              <span className="workflow-step">Feature Scaling</span>
              <span className="workflow-arrow">→</span>
              <span className="workflow-step">Random Forest</span>
              <span className="workflow-arrow">→</span>
              <span className="workflow-step">Prediction</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
