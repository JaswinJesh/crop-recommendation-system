import React from 'react';
import { TrendingUp, DollarSign, Leaf, Award } from 'lucide-react';
import '../styles/ResultsBenefits.css';

const ResultsBenefits = () => {
  const benefits = [
    {
      icon: <TrendingUp size={32} />,
      title: 'Increased Yield',
      description: 'Optimal crop selection can increase harvest yield by 25-40% compared to traditional methods',
      metric: '+35%',
      color: 'green',
    },
    {
      icon: <DollarSign size={32} />,
      title: 'Economic Benefit',
      description: 'Reduced crop failure rates lead to better returns on investment and stable farmer income',
      metric: '₹50K+',
      color: 'green',
    },
    {
      icon: <Leaf size={32} />,
      title: 'Sustainable Farming',
      description: 'Proper crop-soil matching reduces chemical fertilizer dependency and promotes soil health',
      metric: '-30%',
      color: 'green',
    },
    {
      icon: <Award size={32} />,
      title: 'High Accuracy',
      description: 'Machine learning model achieves 96.8% prediction accuracy on test dataset',
      metric: '96.8%',
      color: 'green',
    },
  ];

  const results = [
    { label: 'Model Precision', value: '97.2%' },
    { label: 'Model Recall', value: '96.5%' },
    { label: 'F1-Score', value: '96.8%' },
    { label: 'Training Time', value: '2.3s' },
  ];

  return (
    <section className="results-benefits-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Results & Benefits</h2>
          <p className="section-description">
            Proven impact on agricultural productivity and farmer welfare
          </p>
        </div>
        
        <div className="benefits-grid">
          {benefits.map((benefit, index) => (
            <div key={index} className="benefit-card">
              <div className={`benefit-icon-wrapper ${benefit.color}`}>
                {benefit.icon}
              </div>
              <div className="benefit-metric">{benefit.metric}</div>
              <h3 className="benefit-title">{benefit.title}</h3>
              <p className="benefit-description">{benefit.description}</p>
            </div>
          ))}
        </div>
        
        <div className="results-section">
          <h3 className="results-title">Model Performance Metrics</h3>
          <div className="results-grid">
            {results.map((result, index) => (
              <div key={index} className="result-item">
                <span className="result-label">{result.label}</span>
                <span className="result-value">{result.value}</span>
              </div>
            ))}
          </div>
          <p className="results-note">
            Evaluated on a test set of 500 samples with stratified sampling to ensure balanced class representation
          </p>
        </div>
        
        <div className="impact-section">
          <div className="impact-card">
            <h3 className="impact-title">Real-World Impact</h3>
            <p className="impact-text">
              This system has the potential to transform agricultural practices by providing farmers with scientific, data-backed crop recommendations. By bridging the gap between advanced machine learning technology and grassroots farming, we can contribute to food security, economic stability, and environmental sustainability.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResultsBenefits;
