import React from 'react';
import { AlertTriangle, TrendingDown, Users, Globe } from 'lucide-react';
import '../styles/ProblemStatement.css';

const ProblemStatement = () => {
  const problems = [
    {
      icon: <TrendingDown size={28} />,
      title: 'Low Agricultural Yield',
      description: 'Inappropriate crop selection leads to suboptimal harvests and reduced farmer income',
    },
    {
      icon: <AlertTriangle size={28} />,
      title: 'Soil Degradation',
      description: 'Growing unsuitable crops depletes soil nutrients and damages long-term fertility',
    },
    {
      icon: <Users size={28} />,
      title: 'Knowledge Gap',
      description: 'Farmers lack access to scientific data and expert agricultural guidance',
    },
    {
      icon: <Globe size={28} />,
      title: 'Climate Uncertainty',
      description: 'Changing weather patterns make traditional crop selection methods unreliable',
    },
  ];

  return (
    <section className="problem-section">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Problem Statement</h2>
          <p className="section-description">
            Addressing critical challenges in modern agriculture
          </p>
        </div>
        
        <div className="problem-intro">
          <p className="problem-text">
            Agriculture is the backbone of the global economy, yet farmers face significant challenges in determining the optimal crop for their land. Traditional methods rely on experience and guesswork, often resulting in poor yields, economic losses, and environmental degradation. With climate change introducing new uncertainties, there is an urgent need for a scientific, data-driven approach to crop selection.
          </p>
        </div>
        
        <div className="problems-grid">
          {problems.map((problem, index) => (
            <div key={index} className="problem-card">
              <div className="problem-icon">{problem.icon}</div>
              <h3 className="problem-title">{problem.title}</h3>
              <p className="problem-description">{problem.description}</p>
            </div>
          ))}
        </div>
        
        <div className="solution-highlight">
          <div className="solution-content">
            <h3 className="solution-title">Our Solution</h3>
            <p className="solution-text">
              The AI Crop Recommendation System bridges this gap by leveraging machine learning to analyze soil composition, environmental conditions, and historical agricultural data. It empowers farmers with precise, scientific recommendations that maximize yield while promoting sustainable farming practices.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemStatement;
