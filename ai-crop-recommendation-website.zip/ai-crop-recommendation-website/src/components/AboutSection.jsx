import React from 'react';
import { Brain, Target, Zap } from 'lucide-react';
import '../styles/AboutSection.css';

const AboutSection = () => {
  return (
    <section className="about-section" id="about">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">About the Project</h2>
          <p className="section-description">
            An intelligent system designed to revolutionize agricultural decision-making
          </p>
        </div>
        
        <div className="about-content">
          <div className="about-image-wrapper">
            <img 
              src="https://images.unsplash.com/photo-1769259046907-a5165e978af5?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzR8MHwxfHNlYXJjaHwyfHxtb2Rlcm4lMjBhZ3JpY3VsdHVyZSUyMHRlY2hub2xvZ3l8ZW58MHx8fHwxNzc1ODAwNDkwfDA&ixlib=rb-4.1.0&q=85"
              alt="Smart Agriculture"
              className="about-image"
            />
          </div>
          
          <div className="about-text">
            <p className="about-paragraph">
              The AI Crop Recommendation System is a machine learning-powered solution that assists farmers and agricultural professionals in making data-driven decisions about crop selection. By analyzing critical soil and environmental parameters, our system provides accurate crop recommendations tailored to specific field conditions.
            </p>
            
            <p className="about-paragraph">
              Developed as a comprehensive machine learning project, this system demonstrates the practical application of Random Forest algorithm in agricultural domain. It processes seven key features—Nitrogen, Phosphorus, Potassium, Temperature, Humidity, pH, and Rainfall—to predict the most suitable crop with high accuracy.
            </p>
            
            <div className="about-features">
              <div className="about-feature-card">
                <div className="feature-icon-wrapper green">
                  <Brain size={24} />
                </div>
                <h3 className="feature-title">ML-Powered</h3>
                <p className="feature-text">Random Forest algorithm with 96.8% accuracy</p>
              </div>
              
              <div className="about-feature-card">
                <div className="feature-icon-wrapper green">
                  <Target size={24} />
                </div>
                <h3 className="feature-title">Data-Driven</h3>
                <p className="feature-text">Trained on 2,500+ real agricultural data points</p>
              </div>
              
              <div className="about-feature-card">
                <div className="feature-icon-wrapper green">
                  <Zap size={24} />
                </div>
                <h3 className="feature-title">Instant Results</h3>
                <p className="feature-text">Real-time predictions with confidence scores</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
