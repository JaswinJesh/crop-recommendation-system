import React, { useState } from 'react';
import { predictCrop } from '../data/mock';
import { Sparkles, Info, TrendingUp, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import '../styles/LiveDemo.css';

const LiveDemo = ({ showDemo }) => {
  const [formData, setFormData] = useState({
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    temperature: '',
    humidity: '',
    ph: '',
    rainfall: '',
  });
  
  const [prediction, setPrediction] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateInputs = () => {
    const { nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall } = formData;
    
    if (!nitrogen || !phosphorus || !potassium || !temperature || !humidity || !ph || !rainfall) {
      toast.error('Please fill all input fields');
      return false;
    }
    
    if (nitrogen < 0 || nitrogen > 140) {
      toast.error('Nitrogen must be between 0-140 kg/ha');
      return false;
    }
    
    if (phosphorus < 5 || phosphorus > 145) {
      toast.error('Phosphorus must be between 5-145 kg/ha');
      return false;
    }
    
    if (potassium < 5 || potassium > 205) {
      toast.error('Potassium must be between 5-205 kg/ha');
      return false;
    }
    
    if (temperature < 8 || temperature > 45) {
      toast.error('Temperature must be between 8-45 °C');
      return false;
    }
    
    if (humidity < 14 || humidity > 100) {
      toast.error('Humidity must be between 14-100 %');
      return false;
    }
    
    if (ph < 3.5 || ph > 9.9) {
      toast.error('pH must be between 3.5-9.9');
      return false;
    }
    
    if (rainfall < 20 || rainfall > 300) {
      toast.error('Rainfall must be between 20-300 mm');
      return false;
    }
    
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateInputs()) return;
    
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const result = predictCrop({
        nitrogen: parseFloat(formData.nitrogen),
        phosphorus: parseFloat(formData.phosphorus),
        potassium: parseFloat(formData.potassium),
        temperature: parseFloat(formData.temperature),
        humidity: parseFloat(formData.humidity),
        ph: parseFloat(formData.ph),
        rainfall: parseFloat(formData.rainfall),
      });
      
      setPrediction(result);
      setIsLoading(false);
      toast.success('Crop prediction generated successfully!');
    }, 1500);
  };

  const handleReset = () => {
    setFormData({
      nitrogen: '',
      phosphorus: '',
      potassium: '',
      temperature: '',
      humidity: '',
      ph: '',
      rainfall: '',
    });
    setPrediction(null);
  };

  const fillSampleData = () => {
    setFormData({
      nitrogen: '90',
      phosphorus: '42',
      potassium: '43',
      temperature: '20.8',
      humidity: '82',
      ph: '6.5',
      rainfall: '202',
    });
    toast.success('Sample data filled');
  };

  return (
    <section className="live-demo-section" id="live-demo">
      <div className="container">
        <div className="section-header">
          <h2 className="section-title">Live Crop Predictor</h2>
          <p className="section-description">
            Enter soil and environmental parameters to get instant crop recommendations
          </p>
        </div>
        
        <div className="demo-container">
          <div className="demo-form-section">
            <div className="demo-header">
              <Sparkles size={24} className="demo-icon" />
              <h3 className="demo-subtitle">Input Parameters</h3>
              <button 
                type="button" 
                className="sample-data-btn"
                onClick={fillSampleData}
              >
                Fill Sample Data
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="demo-form">
              <div className="form-grid">
                <div className="form-group">
                  <label htmlFor="nitrogen" className="form-label">
                    Nitrogen (N)
                    <span className="form-unit">kg/ha</span>
                  </label>
                  <input
                    type="number"
                    id="nitrogen"
                    name="nitrogen"
                    value={formData.nitrogen}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="0-140"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="phosphorus" className="form-label">
                    Phosphorus (P)
                    <span className="form-unit">kg/ha</span>
                  </label>
                  <input
                    type="number"
                    id="phosphorus"
                    name="phosphorus"
                    value={formData.phosphorus}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="5-145"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="potassium" className="form-label">
                    Potassium (K)
                    <span className="form-unit">kg/ha</span>
                  </label>
                  <input
                    type="number"
                    id="potassium"
                    name="potassium"
                    value={formData.potassium}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="5-205"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="temperature" className="form-label">
                    Temperature
                    <span className="form-unit">°C</span>
                  </label>
                  <input
                    type="number"
                    id="temperature"
                    name="temperature"
                    value={formData.temperature}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="8-45"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="humidity" className="form-label">
                    Humidity
                    <span className="form-unit">%</span>
                  </label>
                  <input
                    type="number"
                    id="humidity"
                    name="humidity"
                    value={formData.humidity}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="14-100"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="ph" className="form-label">
                    pH Level
                    <span className="form-unit">pH</span>
                  </label>
                  <input
                    type="number"
                    id="ph"
                    name="ph"
                    value={formData.ph}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="3.5-9.9"
                    step="0.1"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="rainfall" className="form-label">
                    Rainfall
                    <span className="form-unit">mm</span>
                  </label>
                  <input
                    type="number"
                    id="rainfall"
                    name="rainfall"
                    value={formData.rainfall}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="20-300"
                    step="0.1"
                  />
                </div>
              </div>
              
              <div className="form-actions">
                <button 
                  type="submit" 
                  className="btn-primary"
                  disabled={isLoading}
                >
                  {isLoading ? 'Predicting...' : 'Get Recommendation'}
                </button>
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={handleReset}
                >
                  Reset
                </button>
              </div>
            </form>
          </div>
          
          <div className="demo-results-section">
            {!prediction ? (
              <div className="no-prediction">
                <img 
                  src="https://images.unsplash.com/photo-1685474442603-b27a68255660?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2ODl8MHwxfHNlYXJjaHwxfHxjcm9wcyUyMGZhcm1pbmd8ZW58MHx8fHwxNzc1ODAwNDk1fDA&ixlib=rb-4.1.0&q=85"
                  alt="Agriculture"
                  className="placeholder-image"
                />
                <div className="placeholder-content">
                  <Info size={32} className="placeholder-icon" />
                  <h4 className="placeholder-title">Ready to Predict</h4>
                  <p className="placeholder-text">
                    Fill in the soil and environmental parameters on the left, then click "Get Recommendation" to receive your personalized crop suggestion.
                  </p>
                </div>
              </div>
            ) : (
              <div className="prediction-results">
                <div className="result-header">
                  <TrendingUp size={28} className="result-icon" />
                  <h3 className="result-title">Prediction Results</h3>
                </div>
                
                <div className="recommended-crop">
                  <span className="crop-label">Recommended Crop</span>
                  <h2 className="crop-name">{prediction.recommendedCrop}</h2>
                  <div className="confidence-badge">
                    {prediction.confidence}% Confidence
                  </div>
                </div>
                
                <div className="result-card">
                  <h4 className="result-card-title">
                    <Info size={18} />
                    Reasoning
                  </h4>
                  <p className="result-card-text">{prediction.reasoning}</p>
                </div>
                
                <div className="result-card">
                  <h4 className="result-card-title">
                    <TrendingUp size={18} />
                    Soil Health Score
                  </h4>
                  <div className="health-bar">
                    <div 
                      className="health-progress" 
                      style={{ width: `${prediction.soilHealth}%` }}
                    ></div>
                  </div>
                  <span className="health-value">{prediction.soilHealth}/100</span>
                </div>
                
                <div className="result-card">
                  <h4 className="result-card-title">
                    <AlertCircle size={18} />
                    Fertilizer Advice
                  </h4>
                  <p className="result-card-text">{prediction.fertilizerAdvice}</p>
                </div>
                
                <div className="alternatives-section">
                  <h4 className="alternatives-title">Alternative Crops</h4>
                  <div className="alternatives-list">
                    {prediction.alternatives.map((crop, index) => (
                      <span key={index} className="alternative-crop">
                        {crop}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveDemo;
