import React, { useState } from 'react';
import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import ProblemStatement from '../components/ProblemStatement';
import HowItWorks from '../components/HowItWorks';
import InputFeatures from '../components/InputFeatures';
import ModelInfo from '../components/ModelInfo';
import ResultsBenefits from '../components/ResultsBenefits';
import LiveDemo from '../components/LiveDemo';
import Footer from '../components/Footer';

const Home = () => {
  const [showDemo, setShowDemo] = useState(false);

  const scrollToDemo = () => {
    setShowDemo(true);
    setTimeout(() => {
      document.getElementById('live-demo')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="home-container">
      <HeroSection onTryDemo={scrollToDemo} />
      <AboutSection />
      <ProblemStatement />
      <HowItWorks />
      <InputFeatures />
      <ModelInfo />
      <ResultsBenefits />
      <LiveDemo showDemo={showDemo} />
      <Footer />
    </div>
  );
};

export default Home;
