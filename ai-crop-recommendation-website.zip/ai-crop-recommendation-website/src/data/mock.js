// Mock data for AI Crop Recommendation System

export const cropDatabase = [
  { name: 'Rice', icon: '🌾', optimalConditions: 'High nitrogen, warm & humid climate' },
  { name: 'Wheat', icon: '🌾', optimalConditions: 'Moderate nutrients, cool & dry climate' },
  { name: 'Cotton', icon: '🌸', optimalConditions: 'High potassium, warm climate' },
  { name: 'Maize', icon: '🌽', optimalConditions: 'Balanced NPK, moderate climate' },
  { name: 'Sugarcane', icon: '🎋', optimalConditions: 'High nitrogen, warm & humid' },
  { name: 'Pulses', icon: '🫘', optimalConditions: 'Low nitrogen, moderate climate' },
  { name: 'Coffee', icon: '☕', optimalConditions: 'Acidic soil, cool & humid' },
  { name: 'Jute', icon: '🌿', optimalConditions: 'High humidity, alluvial soil' },
];

// Mock prediction function
export const predictCrop = (inputs) => {
  const { nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall } = inputs;
  
  // Simple rule-based mock prediction logic
  let recommendedCrop = '';
  let confidence = 0;
  let reasoning = '';
  
  if (nitrogen > 80 && humidity > 70 && rainfall > 200) {
    recommendedCrop = 'Rice';
    confidence = 94;
    reasoning = 'High nitrogen content and humid conditions with good rainfall are ideal for rice cultivation.';
  } else if (temperature < 25 && rainfall < 100) {
    recommendedCrop = 'Wheat';
    confidence = 91;
    reasoning = 'Moderate temperature and lower rainfall conditions favor wheat production.';
  } else if (potassium > 40 && temperature > 25) {
    recommendedCrop = 'Cotton';
    confidence = 88;
    reasoning = 'High potassium levels and warm temperature are perfect for cotton growth.';
  } else if (nitrogen > 50 && phosphorus > 40 && potassium > 40) {
    recommendedCrop = 'Maize';
    confidence = 92;
    reasoning = 'Balanced NPK ratio indicates excellent conditions for maize cultivation.';
  } else if (ph < 6.5 && rainfall > 150) {
    recommendedCrop = 'Coffee';
    confidence = 87;
    reasoning = 'Acidic soil with good rainfall creates optimal conditions for coffee plantation.';
  } else if (humidity > 80 && rainfall > 200) {
    recommendedCrop = 'Jute';
    confidence = 89;
    reasoning = 'High humidity and rainfall favor jute cultivation in alluvial soil.';
  } else if (nitrogen > 70 && temperature > 27) {
    recommendedCrop = 'Sugarcane';
    confidence = 90;
    reasoning = 'High nitrogen and warm climate are excellent for sugarcane production.';
  } else {
    recommendedCrop = 'Pulses';
    confidence = 85;
    reasoning = 'Current soil conditions are suitable for pulse crops like lentils and chickpeas.';
  }
  
  // Generate alternative recommendations
  const alternatives = cropDatabase
    .filter(crop => crop.name !== recommendedCrop)
    .sort(() => Math.random() - 0.5)
    .slice(0, 3);
  
  return {
    recommendedCrop,
    confidence,
    reasoning,
    alternatives: alternatives.map(crop => crop.name),
    soilHealth: Math.floor(70 + Math.random() * 25),
    fertilizerAdvice: generateFertilizerAdvice(nitrogen, phosphorus, potassium),
  };
};

const generateFertilizerAdvice = (n, p, k) => {
  const advice = [];
  
  if (n < 50) advice.push('Consider adding nitrogen-rich fertilizers like urea.');
  if (p < 30) advice.push('Phosphorus levels are low. Add DAP or SSP.');
  if (k < 30) advice.push('Potassium supplementation recommended (MOP).');
  
  if (advice.length === 0) {
    return 'Nutrient levels are balanced. Maintain current fertilization schedule.';
  }
  
  return advice.join(' ');
};

export const projectStats = [
  { label: 'Model Accuracy', value: '96.8%', icon: '🎯' },
  { label: 'Crops Supported', value: '22+', icon: '🌾' },
  { label: 'Data Points', value: '2.5K+', icon: '📊' },
  { label: 'Features Used', value: '7', icon: '🔬' },
];

export const howItWorksSteps = [
  {
    step: 1,
    title: 'Data Collection',
    description: 'Collect soil and environmental parameters including NPK values, temperature, humidity, pH, and rainfall data.',
    icon: '📋',
  },
  {
    step: 2,
    title: 'Data Preprocessing',
    description: 'Clean and normalize the input data. Handle missing values and scale features for optimal model performance.',
    icon: '⚙️',
  },
  {
    step: 3,
    title: 'Model Prediction',
    description: 'Random Forest algorithm analyzes patterns in the data using 100+ decision trees to make accurate predictions.',
    icon: '🤖',
  },
  {
    step: 4,
    title: 'Crop Recommendation',
    description: 'Get the best crop recommendation with confidence score, reasoning, and alternative crop suggestions.',
    icon: '✅',
  },
];

export const inputFeatures = [
  { name: 'Nitrogen (N)', unit: 'kg/ha', range: '0-140', description: 'Essential for leaf growth and protein synthesis', icon: '🔵' },
  { name: 'Phosphorus (P)', unit: 'kg/ha', range: '5-145', description: 'Critical for root development and energy transfer', icon: '🟠' },
  { name: 'Potassium (K)', unit: 'kg/ha', range: '5-205', description: 'Regulates water uptake and disease resistance', icon: '🟢' },
  { name: 'Temperature', unit: '°C', range: '8-45', description: 'Affects germination and growth rate', icon: '🌡️' },
  { name: 'Humidity', unit: '%', range: '14-100', description: 'Influences disease susceptibility and water stress', icon: '💧' },
  { name: 'pH Level', unit: 'pH', range: '3.5-9.9', description: 'Determines nutrient availability in soil', icon: '⚗️' },
  { name: 'Rainfall', unit: 'mm', range: '20-300', description: 'Primary water source for crop growth', icon: '🌧️' },
];
